package net.greg.examples.serverless;

public class Response {

	private final String message;
	public Response(String value) { message = value; }
	public String getMessage() { return message; }
}
